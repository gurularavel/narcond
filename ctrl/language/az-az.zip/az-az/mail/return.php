<?php
// Text
$_['text_subject']       = '%s - Return Update %s';
$_['text_return_id']     = 'Geri qaytarma №:';
$_['text_date_added']    = 'Tarix:';
$_['text_return_status'] = 'Geri qaytarmanın statusu dəyişdirildi:';
$_['text_comment']       = 'Geri qaytarma qeydi:';
$_['text_footer']        = 'Hər hansı sual yaranarsa bu məktubu cavablayın.';