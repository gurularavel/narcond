<?php
// Text
$_['text_subject'] = '%s - Sizin hesabınız aktivləşdirildi!';
$_['text_welcome'] = 'Xoşgəlmisiniz, %s -da qeydiyyatdan keçdiyiniz üçün təşəkkür edirik!';
$_['text_login']   = 'Sizin hesabınız artıq yaradılıb. Siz öz e-mail ünvanı və şifrəniz ilə bizim mağazamıza daxil ola bilərsiniz və yaxud hesabınıza daxil olmaq üçün aşağıdakı keçidi də istifadə edə bilərsiniz:';
$_['text_service'] = 'Hesabınıza daxil olduqdan sonra siz keçmiş sifarişlərə baxa bilər, fakturaları çap edə bilər, hesab məlumatlarınızı redaktə edə bilər və sairə xidmətlərimizdən istifadə edə bilərsiniz.';
$_['text_thanks']  = 'Təşəkkürlər,';