<?php
// Text
$_['text_subject'] = '%s - Ortaqlıq hesabı reddedildi!';
$_['text_welcome'] = 'Xoşgəlmisiniz, %s -da qeydiyyatdan keçdiyiniz üçün təşəkkür edirik!';
$_['text_denied']  = 'Unfortunately your request has been denied. For more information you can contact the store owner here:';
$_['text_thanks']  = 'Təşəkkürlər,';