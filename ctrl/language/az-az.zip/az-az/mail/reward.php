<?php
// Text
$_['text_subject']  = '%s - Bonus xalı';
$_['text_received'] = 'Siz %s bonus xalı əldə etdiniz!';
$_['text_total']    = 'Sizin ümumi bonus xalınız %s.';