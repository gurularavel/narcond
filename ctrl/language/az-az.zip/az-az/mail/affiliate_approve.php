<?php
// Text
$_['text_subject']  = '%s - Ortaqlıq hesabı aktivləşdirildi!';
$_['text_welcome']  = 'Xoşgəlmisiniz, %s -da qeydiyyatdan keçdiyiniz üçün təşəkkür edirik!';
$_['text_login']    = 'Sizin hesabınız artıq yaradılıb. Siz öz e-mail ünvanı və şifrəniz ilə bizim mağazamıza daxil ola bilərsiniz və yaxud hesabınıza daxil olmaq üçün aşağıdakı keçidi də istifadə edə bilərsiniz:';
$_['text_services'] = 'Təəssüf ki, sorğunuz rədd edildi. Əlavə məlumat üçün mağazanın sahibinə müraciət edə bilərsiniz:';
$_['text_thanks']   = 'Təşəkkürlər,';