<?php
// Text
$_['text_subject']  = '%s - Şifrəni yeniləmə sorğusu';
$_['text_greeting'] = 'Yeni şifrə sorğusu %s administrasiyası.';
$_['text_change']   = 'Keçidə klik edərək şifrənizi yeniləyə bilərsiniz:';
$_['text_ip']       = 'Sorğu üçün istifadə edilən IP: %s';