<?php
// Text
$_['text_success']  = 'Success: You have modified vouchers!';
$_['text_subject']  = 'Siz %s -dan hədiyyə kartı göndərmisiniz';
$_['text_greeting'] = 'Təbriklər, Siz %s dəyərində hədiyyə kartı əldə etmisiniz';
$_['text_from']     = 'Bu hədiyyə kartı %s tərəfindən göndərilib';
$_['text_message']  = 'Mesajda deyilir:';
$_['text_redeem']   = '<b>%s</b> kodlu hədiyyə kartını istifadə etmək üçün sifariş verdiyiniz zaman hədiyyə kartını yazaraq hədiyyə kartını işlət düyməsini vasitəsi ilə ödəməni həyata keçirə bilərsiniz.';
$_['text_footer']   = 'Hər hansı bir sualınız yaranarsa, bu e-mail-ə cavab olaraq göndərə bilərsiniz.';