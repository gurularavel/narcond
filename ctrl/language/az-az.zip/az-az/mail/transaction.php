<?php
// Text
$_['text_subject']  = '%s - Hesab krediti';
$_['text_received'] = 'Siz %s kredit əldə etdiniz!';
$_['text_total']    = 'Sizin hal-hazırda ümumi kredit məbləğiniz %s.' . "\n\n" . 'Sizin kreditinizdən növbəti sifariş zamanı avtomatik çıxılacaq.';
$_['text_credit']   = 'Your account credit can deducted from your next purchase.';