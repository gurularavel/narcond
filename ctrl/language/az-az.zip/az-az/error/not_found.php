<?php
// Heading
$_['heading_title']  = 'Səhifə mövcud deyil!';

// Text
$_['text_not_found'] = 'Axtardığınız səhifə tapılmadı! Əgər problem davam edirsə idarəçi ilə əlaqə saxlayın.';