<?php
// Heading
$_['heading_title']   = 'İcazəniz yoxdur!';

// Text
$_['text_permission'] = 'Sizin bu səhifəyə baxmaq icazəniz yoxdur. Zəhmət olmasa idarəçi ilə əlaqə saxlayın';