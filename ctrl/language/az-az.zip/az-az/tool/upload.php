<?php
// Heading
$_['heading_title']     = 'Yükləmələr';

// Text
$_['text_success']      = 'Siz müvəffəqiyyətlə yükləmələri redaktə etdiniz!';
$_['text_list']         = 'Yükləmə siyahısı';

// Column
$_['column_name']       = 'Yükləmə adı';
$_['column_filename']   = 'Faylın adı';
$_['column_date_added'] = 'Tarix';
$_['column_action']     = 'Hərəkət';

// Entry
$_['entry_name']        = 'Yükləmə adı';
$_['entry_filename']    = 'Faylın adı';
$_['entry_date_added'] 	= 'Tarix';

// Error
$_['error_permission']  = 'Sizin yükləmələri redaktə etmə icazəniz yoxdur!';