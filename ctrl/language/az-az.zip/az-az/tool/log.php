<?php
// Heading
$_['heading_title']	   = 'Xəta qeydləri';

// Text
$_['text_success']	   = 'Siz xəta qeydlərini müvəffəqiyyətlə təmizlədiniz!';
$_['text_list']        = 'Xəta siyahısı';

// Error
$_['error_warning']	   = 'Sizin xəta qeyd faylı %s  %s -dır!';
$_['error_permission'] = 'Sizin xəta qeydlərini təmizləmə icazəniz yoxdur!';