<?php
// Heading
$_['heading_title']  = 'İdarəetmə';

// Text
$_['text_heading']   = 'İdarəetmə';
$_['text_login']     = 'Zəhmət olmasa, giriş məlumatlarını daxil edin.';
$_['text_forgotten'] = 'Forgotten Password';

// Entry
$_['entry_username'] = 'İstifadəçi adı';
$_['entry_password'] = 'Şifrə';

// Button
$_['button_login']   = 'Giriş';

// Error
$_['error_login']    = 'İstifadəçi adı və ya şifrə düzgün deyil.';
$_['error_token']    = 'Xətalı sessiya tokeni. Zəhmət olmasa, yenidən giriş edin';