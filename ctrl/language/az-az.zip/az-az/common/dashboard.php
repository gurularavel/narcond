<?php
// Heading
$_['heading_title']		= 'Dashboard';

// Error
$_['error_install']		= 'Quraşdırma qovluğu hələ də qalmaqdadır. Onu silmək sizin təhlükəsizliyiniz üçün zəruridir!';