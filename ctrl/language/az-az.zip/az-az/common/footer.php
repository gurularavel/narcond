<?php
// Text
$_['text_footer']  = 'Azerbaijan Tərcümə <a href="https://www.tematimi.com" title="Tematimi" alt="Tematimi">Tematimi</a><br /><a href="http://www.opencart.com">OpenCart</a> &copy; 2009 - ' . date('Y') . ' Bütün hüquqlar qorunur.';
$_['text_version'] = 'Versiya %s';