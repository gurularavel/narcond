<?php
// Heading
$_['heading_title']  = 'Şifrəni sıfırla';

// Text
$_['text_password']  = 'İstifadə etmək istədiyiniz yeni şifrəni yazın.';
$_['text_success']   = 'Şifrəniz uğurla dəyişdirildi.';

// Entry
$_['entry_password'] = 'Şifrə';
$_['entry_confirm']  = 'Şifrə (təkrar)';

// Error
$_['error_password'] = 'Şifrə 5 ilə 20 simvol arası olmalıdır!';
$_['error_confirm']  = 'Şifrə təkrarı ilə eyni deyil!';