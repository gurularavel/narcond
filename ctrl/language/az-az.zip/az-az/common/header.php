<?php
// Heading
$_['heading_title']		   = 'OpenCart';

// Text
$_['text_profile']         = 'Profil';
$_['text_store']           = 'Mağaza';
$_['text_help']            = 'Kömək';
$_['text_homepage']        = 'Baş səhifə';
$_['text_support']         = 'Dəstək forumu';
$_['text_documentation']   = 'Dokumentasiya';
$_['text_logout']          = 'Çıxış';