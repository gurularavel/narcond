<?php
// Heading
$_['heading_title']    = 'Aşağı dəyərli sifariş haqqı';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz aşağı dəyərli sifariş haqqı yekunu müvəffəqqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Aşağı dəyərli sifariş haqqı';

// Entry
$_['entry_total']      = 'Sifariş məbləği';
$_['entry_fee']        = 'Qiyməti';
$_['entry_tax_class']  = 'ƏDV sinifi';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Help
$_['help_total']       = 'Sifariş məbləği göstərilənə çatdığı təqdirdə bu ödəniş deaktiv olacaq.';

// Error
$_['error_permission'] = 'Sizin aşağı dəyərli sifariş haqqı yekununu redaktə etməyə icazəniz yoxdur!';
