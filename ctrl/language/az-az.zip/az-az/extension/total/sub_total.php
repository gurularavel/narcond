<?php
// Heading
$_['heading_title']    = 'Məbləğ';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz məbləğ yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Məbləğ yekunu redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin məbləğ yekunu redaktə etmə icazəniz yoxdur!';