<?php
// Heading
$_['heading_title']    = 'Vergilər';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz vergilər yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Vergilər yekununu redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin vergilər yekunu redaktə etmə icazəniz yoxdur!';