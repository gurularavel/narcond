<?php
// Heading
$_['heading_title']    = 'Mağaza krediti';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz mağaza kredit yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Mağaza kreditini redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Siz mağaza krediti yekunu redaktə etmə icazəniz yoxdur!';