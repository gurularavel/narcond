<?php
// Heading
$_['heading_title']    = 'Çatdırılma';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz çatdırılma yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Çatdırılma yekununu redaktə et';

// Entry
$_['entry_estimator']  = 'Çatdırılma qiymətləndirməsi';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sırala';

// Error
$_['error_permission'] = 'Sizin çatdırılma yekununu redaktə etmək icazəniz yoxdur!';