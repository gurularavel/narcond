<?php
// Heading
$_['heading_title']    = 'Bonus xalları';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz bonus xalları yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Bonus xalları yekunu';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin bonus xalları yekunu redaktə etmə icazəniz yoxdur!';