<?php
// Heading
$_['heading_title']    = 'Kupon';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz kuponu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Kuponu redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin kupon yekunu redaktə etmə icazəniz yoxdur!';