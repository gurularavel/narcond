<?php
// Heading
$_['heading_title']    = 'Ümumi məbləğ';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz ümumi məbləğ yekununu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Ümumi məbləğ yekunu redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sırala';

// Error
$_['error_permission'] = 'Sizin ümumi məbləğ yekunu redaktə etmə icazəniz yoxdur!';