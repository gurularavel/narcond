<?php
// Heading
$_['heading_title']    = 'Hədiyyə kartı';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz hədiyyə kartı yekunu müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Hədiyyə kartı yekunu redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin hədiyyə kartı yekunu redaktə etmək icazəniz yoxdur!';