<?php
// Heading
$_['heading_title']    = 'Google Sayt xəritəsi';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Google Sayt xəritəsini müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Google Sayt xəritəsini redaktə et';

// Entry
$_['entry_status']     = 'Status';
$_['entry_data_feed']  = 'Data Resurs URL';

// Error
$_['error_permission'] = 'Sizin Google Sayt xəritəsini redaktə etmə icazəniz yoxdur!';