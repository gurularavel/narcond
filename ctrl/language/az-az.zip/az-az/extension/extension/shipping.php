<?php
// Heading
$_['heading_title']     = 'Çatdırılma';

// Text
$_['text_success']      = 'Çatdırılmanı müvəffəqiyyətlə yenilədiniz!';
$_['text_list']         = 'Çatdırılma siyahısı';

// Column
$_['column_name']       = 'Çatdırılma növü';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sıralama';
$_['column_action']     = 'Hərəkət';

// Error
$_['error_permission']  = 'Çatdırılmanı redaktə etmək icazəniz yoxdur!';