<?php
// Heading
$_['heading_title']    = 'Resurslar';

// Text
$_['text_success']     = 'Siz müvəffəqiyyətlə resursları redaktə etdiniz!';
$_['text_list']        = 'Resurs siyahısı';

// Column
$_['column_name']      = 'Məhsul resursu adı';
$_['column_status']    = 'Status';
$_['column_action']    = 'Hərəkət';

// Error
$_['error_permission'] = 'Sizin resursu redaktə etmək icazəniz yoxdur!';