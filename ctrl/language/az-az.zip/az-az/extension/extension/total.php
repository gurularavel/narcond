<?php
// Heading
$_['heading_title']     = 'Sifariş yekunu';

// Text
$_['text_success']      = 'Siz sifariş yekununu müvəffəqiyyətlə yenilədiniz!';
$_['text_list']         = 'Sifariş yekunu siyahısı';

// Column
$_['column_name']       = 'Sifariş yekunu';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sıralama';
$_['column_action']     = 'Hərəkət';

// Error
$_['error_permission']  = 'Sifariş yekununu redaktə etmək üçün icazəniz yoxdur!';