<?php
// Heading
$_['heading_title']     = 'Ödəmələr';

// Text
$_['text_success']      = 'Siz ödəmələri müvəffəqiyyətlə redaktə etdiniz!';
$_['text_list']         = 'Ödəmə siyahısı';
$_['text_recommended']  = 'Payments - Recommended Solutions';

// Column
$_['column_name']       = 'Ödəmə növləri';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sıralama';
$_['column_action']     = 'Hərəkət';

// Error
$_['error_permission']  = 'Sizin ödəmələ növlərini redaktə etmək icazəniz yoxdur!';