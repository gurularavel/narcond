<?php
// Heading
$_['heading_title']    = 'Sabit qiymət';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Sabit qiymətli çatdırılma servisini müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Sabit qiymətli çatdırılma servisi redaktə et';

// Entry
$_['entry_cost']       = 'Qiyməti';
$_['entry_tax_class']  = 'Vergi sinifi';
$_['entry_geo_zone']   = 'Coğrafi region';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin sabit qiymətli çatdırılma servisini redaktə etmə icazəniz yoxdur!';