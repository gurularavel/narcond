<?php
// Heading
$_['heading_title']     = 'Məhsul sayına görə';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Məhsul sayına görə çatdırılmanı müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Məhsul sayına görə çatdırılmanı redaktə et';

// Entry
$_['entry_cost']       = 'Qiyməti';
$_['entry_tax_class']  = 'Vergi sinifi';
$_['entry_geo_zone']   = 'Coğrafi region';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Sizin məhsul sayına görə çatdırılmanı redaktə etmə icazəniz yoxdur!';