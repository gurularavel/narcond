<?php
// Heading
$_['heading_title']    = 'Mağazadan götürmə';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz mağazadan götürmə çatdırılma növünü müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Mağazadan götürmə çatdırılmasını redaktə et';

// Entry
$_['entry_geo_zone']   = 'Coğrafi region';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Error
$_['error_permission'] = 'Mağazadan çatdırılmanı redaktə etmə icazəniz yoxdur!';