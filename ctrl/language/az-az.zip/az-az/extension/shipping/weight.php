<?php
// Heading
$_['heading_title']    = 'Çəki əsaslı çatdırılma';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Çəki əsaslı çatdırılmanı müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Çəki əsaslı çatdırılmanı redaktə et';

// Entry
$_['entry_rate']       = 'Dəyəri';
$_['entry_tax_class']  = 'Vergi sinifi';
$_['entry_geo_zone']   = 'Coğrafi region';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Help
$_['help_rate']        = 'Məsələn: 5:10.00,7:12.00 Çəki:Qiymət,Çəki:Qiymət, və sair..';

// Error
$_['error_permission'] = 'Sizin çəki əsaslı çatdırılmanı redaktə etmə icazəniz yoxdur!';