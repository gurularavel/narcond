<?php
// Heading
$_['heading_title']    = 'Pulsuz çatdırılma';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Siz pulsuz çatdırılma servisini müvəffəqiyyətlə redaktə etdiniz!';
$_['text_edit']        = 'Pulsuz çatdırılma servisini redaktə et';

// Entry
$_['entry_total']      = 'Məbləğ';
$_['entry_geo_zone']   = 'Coğrafi region';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sıralama';

// Help
$_['help_total']       = 'Qeyd etdiyiniz məbləğdə sifariş zamanı pulsuz çatdırılma aktivləşəcək.';

// Error
$_['error_permission'] = 'Sizin pulsuz çatdırılma servisini redaktə etmə icazəniz yoxdur!';