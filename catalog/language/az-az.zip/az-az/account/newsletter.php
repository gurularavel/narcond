<?php
// Heading
$_['heading_title']    = 'Bülleten abunəliyi';

// Text
$_['text_account']     = 'Hesab';
$_['text_newsletter']  = 'Xəbər bülleteni';
$_['text_success']     = 'Xəbər bülletinimizə abunəliyiniz yeniləndi!';

// Entry
$_['entry_newsletter'] = 'Abunə ol';