<?php
// Heading
$_['heading_title']     = 'Yükləmələr';

// Text
$_['text_account']      = 'Hesab';
$_['text_downloads']    = 'Yükləmələr';
$_['text_empty']        = 'Hər hansı yüklənə biləcək sifarişiniz mövcud deyil!';

// Column
$_['column_order_id']   = 'Sifariş №';
$_['column_name']       = 'Ad';
$_['column_size']       = 'Ölçü';
$_['column_date_added'] = 'Tarix';