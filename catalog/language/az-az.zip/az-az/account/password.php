<?php
// Heading
$_['heading_title']  = 'Şifrəni dəyiş';

// Text
$_['text_account']   = 'Hesab';
$_['text_password']  = 'Şifrə';
$_['text_success']   = 'Şifrəniz müvəffəqiyyətlə dəyişdirildi.';

// Entry
$_['entry_password'] = 'Şifrə';
$_['entry_confirm']  = 'Şifrə (təkrar)';

// Error
$_['error_password'] = 'Şifrə 4 ilə 20 simvol arası olmalıdır!';
$_['error_confirm']  = 'Şifrə təkrarı ilə eyni deyil!';