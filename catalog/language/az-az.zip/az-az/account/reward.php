<?php
// Heading
$_['heading_title']      = 'Bonus xalı';

// Column
$_['column_date_added']  = 'Tarix';
$_['column_description'] = 'Açıqlama';
$_['column_points']      = 'Xal';

// Text
$_['text_account']       = 'Hesab';
$_['text_reward']        = 'Bonus';
$_['text_total']         = 'Bonus xallarının cəmi:';
$_['text_empty']         = 'Sizin bonus xalınız yoxdur!';