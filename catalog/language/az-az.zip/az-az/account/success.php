<?php
// Heading
$_['heading_title'] = 'Hesabınız yaradıldı!';

// Text
$_['text_message']  = '<p>Təbrikıər! Sizin hesabınız müvəffəqiyyətlə yaradıldı!</p>';
$_['text_approval'] = '<p>Qeydiyyatdan keçdiyiniz üçün təşəkkür edirik!</p><p>Hesabınızın təsdiqlənməsi barədə bildiriş e-mail vasitəsi ilə göndəriləcək.</p>';
$_['text_account']  = 'Hesab';
$_['text_success']  = 'Müvəffəqiyyət';