<?php
// Heading
$_['heading_title'] = 'Hesab çıxışı';

// Text
$_['text_message']  = '<p>Siz hesabınızdan müvəffəqiyyətlə çıxış etdiniz.</p>';
$_['text_account']  = 'Hesab';
$_['text_logout']   = 'Çıxış';