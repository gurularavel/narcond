<?php
// Heading
$_['heading_title'] = 'Arzu siyahısı';

// Text
$_['text_account']  = 'Hesab';
$_['text_instock']  = 'Anbarda';
$_['text_wishlist'] = 'Arzu siyahısı (%s)';
$_['text_login']    = 'Siz əvvəlcə<a href="%s">giriş etməli</a> və ya <a href="%s">hesab yaratmalısınız</a>!';
$_['text_success']  = '<a href="%s">%s</a>  <a href="%s">arzu siyahınıza</a> müvəffəqiyyətlə əlavə ediildi!';
$_['text_remove']   = 'Arzu siyahınızı müvəffəqiyyətlə yenilədiniz!';
$_['text_empty']    = 'Sizin arzu siyahınız boşdur.';

// Column
$_['column_image']  = 'Şəkil';
$_['column_name']   = 'Məhsulun adı';
$_['column_model']  = 'Model';
$_['column_stock']  = 'Anbar';
$_['column_price']  = 'Qiyməti';
$_['column_action'] = 'Hərəkət';