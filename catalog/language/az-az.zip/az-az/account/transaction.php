<?php
// Heading
$_['heading_title']      = 'Əməliyyatlar';

// Column
$_['column_date_added']  = 'Tarix';
$_['column_description'] = 'Açıqlama';
$_['column_amount']      = 'Hesab (%s)';

// Text
$_['text_account']       = 'Hesab';
$_['text_transaction']   = 'Əməliyyatlar';
$_['text_total']         = 'Balansınız:';
$_['text_empty']         = 'Sizin hər hansı əməliyyatınız mövcud deyil!';