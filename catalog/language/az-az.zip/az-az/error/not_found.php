<?php
// Heading
$_['heading_title'] = 'Səhifə mövcud deyil!';

// Text
$_['text_error']    = 'Səhifə mövcud deyil.';