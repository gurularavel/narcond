<?php
// Heading
$_['heading_title']        = 'Sizin sifarişiniz qeydə alındı!';

// Text
$_['text_basket']          = 'Səbət';
$_['text_checkout']        = 'Sifarişi rəsmiləşdir';
$_['text_success']         = 'Müvəffəqiyyət';
$_['text_customer']        = '<p>Sizin sifarişiniz qeydə alındı!</p><p>Siz <a href="%s">hesabım</a> səhifəsində <a href="%s">sifariş tarixçəsinə</a> baxa bilərsiniz</p><p>Hər hansı sualınız yaranarsa, <a href="%s">mağaza administrasiyası</a> ilə əlaqə saxlayın.</p><p>Bizimlə alış-veriş etdiyiniz üçün təşəkkür edirik!</p>';
$_['text_guest']           = '<p>Sizin sifarişiniz qeydə alındı!</p><p>Hər hansı sualınız yaranarsa, <a href="%s">mağaza administrasiyası</a> ilə əlaqə saxlayın.</p><p>Bizimlə alış-veriş etdiyiniz üçün təşəkkür edirik!</p>';