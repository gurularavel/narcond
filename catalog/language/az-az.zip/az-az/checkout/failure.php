<?php
// Heading
$_['heading_title'] = 'Uğursuz ödəmə!';

// Text
$_['text_basket']   = 'Səbət';
$_['text_checkout'] = 'Sifarişi rəsmiləşdir';
$_['text_failure']  = 'Uğursuz ödəmə';
$_['text_message']  = '<p>Sifariş və ödəmə zamanı xəta yarandı: Buna aşağıda qeyd edilənlər səbəb ola bilər:.</p>

<p>Mümkün səbəblər:</p>
<ul>
  <li>Məbləğin çatışmamazlığı</li>
  <li>Təsdiqləmə zamanı xəta</li>
</ul>

<p>Zəhmət olmasa, digər ödəmə növləri ilə bir daha yoxlayın.</p>

<p>Əgər problemi həll etməyə nail ola bilmirsinizsə, <a href="%s">bizimlə əlaqə</a> saxlayın.</p>
';