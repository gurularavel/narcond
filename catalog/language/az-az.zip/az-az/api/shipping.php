<?php
// Text
$_['text_address']       = 'Başarılı: Teslimat adresi ayarlandı!';
$_['text_method']        = 'Başarılı: Kargo metodu ayarlandı!';

// Error
$_['error_permission']   = 'Uyarı: API erişim iznine sahip değilsiniz!';
$_['error_firstname']    = 'Adınız 1 ile 32 karakter arasında olmalıdır!';
$_['error_lastname']     = 'Soyadınız 1 ile 32 karakter arasında olmalıdır!';
$_['error_address_1']    = 'Adres 1 3 ile 128 karakter arasında olmalıdır!';
$_['error_city']         = 'Şehir 3 ile 128 karakter arasında olmalıdır!';
$_['error_postcode']     = 'Bu ülke için posta kodu 2 ile 10 karakter arasında olmalı!';
$_['error_country']      = 'Lütfen bir ülke seçiniz';
$_['error_zone']         = 'Lütfen bir şehir seçiniz!';
$_['error_custom_field'] = '%s gerekli!';
$_['error_address']      = 'Uyarı: Kargo adresi gerekli!';
$_['error_method']       = 'Uyarı: Kargo metodu gerekli!';
$_['error_no_shipping']  = 'Uyarı: Kullanılabilir kargo seçeneği yok!';