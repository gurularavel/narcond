<?php
// Text
$_['text_success']     = 'Səbətinizi müvəffəqiyyətlə yenilədiniz!';

// Error
$_['error_permission'] = 'API-dən istifadə icazəniz mövcud deyil!';
$_['error_stock']      = '*** ilə işarələniş məhsullar anbarda yetərincə mövcud deyil!';
$_['error_minimum']    = '%s üçün minimum sifariş miqdarı: %s!';
$_['error_store']      = 'Seçdiyiniz mağazadan bu məhsulu ala bilməzsiniz!';
$_['error_required']   = '%s zəruridir!';