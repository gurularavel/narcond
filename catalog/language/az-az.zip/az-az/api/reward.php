<?php
// Text
$_['text_success']     = 'Başarılı: Puan indirimi sepetinize başarıyla uygulandı!';

// Error
$_['error_permission'] = 'Uyarı: API erişim iznine sahip değilsiniz!';
$_['error_reward']     = 'Uyarı: Lütfen kullanmak istediğiniz puanı giriniz!';
$_['error_points']     = 'Uyarı: %s puanınız yok!';
$_['error_maximum']    = 'Uyarı: Kullanbileceğiniz en yüksek puan %s!';