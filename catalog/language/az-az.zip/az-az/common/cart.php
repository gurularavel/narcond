<?php
// Text
$_['text_items']		= '%s ədəd - %s';
$_['text_empty']		= 'Səbətiniz boşdur!';
$_['text_cart']			= 'Səbətə bax';
$_['text_checkout']		= 'Sifarişi rəsmiləşdir';
$_['text_recurring']	= 'Ödəmə profili';