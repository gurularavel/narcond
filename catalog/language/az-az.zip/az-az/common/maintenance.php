<?php
// Heading
$_['heading_title']    = 'Təmir bərpa işləri';

// Text
$_['text_maintenance'] = 'Təmir bərpa işləri';
$_['text_message']     = '<h1 style="text-align:center;">Biz hal-hazırda təyin edilmiş təmir bərpa işlərini həyata keçiririk. <br/>Tezliklə fəaliyyətimiz bərpa ediləcək. Zəhmət olmasa, biraz sonra yenidən yoxlayın.</h1>';