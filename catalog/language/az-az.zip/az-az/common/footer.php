<?php
// Text
$_['text_information']  = 'Məlumat';
$_['text_service']      = 'Müştəri xidmətləri';
$_['text_extra']        = 'Əlavələr';
$_['text_contact']      = 'Əlaqə';
$_['text_return']       = 'Geri qaytarma';
$_['text_sitemap']      = 'Sayt xəritəsi';
$_['text_manufacturer'] = 'Bremdlər';
$_['text_voucher']      = 'Hədiyyə kartları';
$_['text_affiliate']    = 'Ortaqlıq';
$_['text_special']      = 'Xüsusi təkliflər';
$_['text_account']      = 'Hesabım';
$_['text_order']        = 'Sifariş tarixçəsi';
$_['text_wishlist']     = 'Arzu siyahısı';
$_['text_newsletter']   = 'Xəbər bülleteni';
$_['text_powered']      = 'Azerbaijan Tərcümə <a href="https://www.tematimi.com" title="Tematimi" alt="Tematimi">Tematimi</a><br /> %s &copy; %s';