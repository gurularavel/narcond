<?php
// Text
$_['text_home']          = 'Baş səhifə';
$_['text_wishlist']      = 'Arzu siyahısı (%s)';
$_['text_shopping_cart'] = 'Səbət';
$_['text_category']      = 'Bölmələr';
$_['text_account']       = 'Hesabım';
$_['text_register']      = 'Qeydiyyat';
$_['text_login']         = 'Giriş';
$_['text_order']         = 'Sifariş tarixçəsi';
$_['text_transaction']   = 'Əməliyyatlar';
$_['text_download']      = 'Yükləmələr';
$_['text_logout']        = 'Çıxış';
$_['text_checkout']      = 'Sifarişi rəsmiləşdir';
$_['text_search']        = 'Axtar';
$_['text_all']           = 'Hamısına bax';