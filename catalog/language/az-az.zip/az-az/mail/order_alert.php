<?php
// Text
$_['text_subject']      = '%s - Sifariş %s';
$_['text_received']     = 'Siparişiniz var.';
$_['text_order_id']     = 'Sifariş №:';
$_['text_date_added']   = 'Sifariş məlumatları:';
$_['text_order_status'] = 'Sifarişin statusu:';
$_['text_products']     = 'Məhsullar:';
$_['text_total']        = 'Məbləğ';
$_['text_comment']      = 'Sifariş üçün qeyd:';