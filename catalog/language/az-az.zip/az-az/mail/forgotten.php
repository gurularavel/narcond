<?php
// Text
$_['text_subject']  = '%s - Yeni şifrə';
$_['text_greeting'] = '%s -dan şifrənin yenilənmə tələbi.';
$_['text_password'] = 'Sizin yeni şifrəniz:';
$_['text_ip']       = 'Şifrənizi sıfırlama sorğusu bu IP ünvanından edilmişdir: %s';