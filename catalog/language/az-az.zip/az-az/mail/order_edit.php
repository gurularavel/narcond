<?php
// Text
$_['text_subject']       = '%s - %s Nolu Siparişinizin Durumu Güncellendi';
$_['text_order_id']      = 'Sifariş №:';
$_['text_date_added']    = 'Sifariş tarixi:';
$_['text_order_status']  = 'Sifarişinizin statusu yeniləndi:';
$_['text_comment']       = 'Sifariş üçün qeyd:';
$_['text_link']          = 'Sifarişinizə baxmaq üçün aşağıdakı keçidə klik edin:';
$_['text_footer']        = 'Hər hansı bir sualınız yaranarsa, bu e-mail-ə cavab olaraq göndərə bilərsiniz.';