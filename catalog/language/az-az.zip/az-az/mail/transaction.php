<?php
// Text
$_['text_subject']  = '%s - Ortaklık Komisyonu';
$_['text_received'] = 'Tebrikler! %s ortaklı programından komisyon ödemesi aldınız.';
$_['text_amount']   = 'Komisyon oranınıza göre kazandığınız bakiye %s dir';
$_['text_total']    = 'Kazandığınız bakiye ile birlikte toplam bakiyeniz %s.';