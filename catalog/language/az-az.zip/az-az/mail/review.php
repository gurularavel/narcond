<?php
// Text
$_['text_subject']	= '%s - Şərh';
$_['text_waiting']	= 'Yeni bir şərh yoxlama üçün gözləyir.';
$_['text_product']	= 'Məhsul: %s';
$_['text_reviewer']	= 'Müəllif: %s';
$_['text_rating']	= 'Reytinq: %s';
$_['text_review']	= 'Şərh:';