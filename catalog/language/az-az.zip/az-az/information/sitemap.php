<?php
// Heading
$_['heading_title']    = 'Sayt xəritəsi';

// Text
$_['text_special']     = 'Xüsusi təkliflər';
$_['text_account']     = 'Hesabım';
$_['text_edit']        = 'Hesab məlumatları';
$_['text_password']    = 'Şifrə';
$_['text_address']     = 'Ünvan kitabçası';
$_['text_history']     = 'Sifariş tarixçəsi';
$_['text_download']    = 'Yükləmələr';
$_['text_cart']        = 'Səbət';
$_['text_checkout']    = 'Sifarişi rəsmiləşdir';
$_['text_search']      = 'Axtar';
$_['text_information'] = 'Məlumat';
$_['text_contact']     = 'Əlaqə';