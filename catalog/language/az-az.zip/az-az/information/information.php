<?php
// Text
$_['text_error'] = 'Səhifə mövcud deyil!';