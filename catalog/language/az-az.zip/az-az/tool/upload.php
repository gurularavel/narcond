<?php
// Text
$_['text_upload']    = 'Fayl müvəffəqiyyətlə yükləndi!';

// Error
$_['error_filename'] = 'Faylın adı 3 ilə 64 simvol arasında olmalıdır!';
$_['error_filetype'] = 'Yanlış fayl növü!';
$_['error_upload']   = 'Yükləmə zəruridir!';