<?php
// Heading
$_['heading_title'] = 'Məlumat';

// Text
$_['text_contact']  = 'Əlaqə';
$_['text_sitemap']  = 'Sayt xəritəsi';