<?php
$_['heading_title'] = 'Bizim eBay mağazamızda';