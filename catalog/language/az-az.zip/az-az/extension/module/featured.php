<?php
// Heading
$_['heading_title'] = 'Seçilmiş məhsullar';

// Text
$_['text_tax']      = 'ƏDV xaric:';