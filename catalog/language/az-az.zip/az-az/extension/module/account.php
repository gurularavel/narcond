<?php
// Heading
$_['heading_title']    = 'Hesab';

// Text
$_['text_register']    = 'Qeydiyyat';
$_['text_login']       = 'Giriş';
$_['text_logout']      = 'Çıxış';
$_['text_forgotten']   = 'Şifrənizi unutmusunuz?';
$_['text_account']     = 'Hesabım';
$_['text_edit']        = 'Hesabı redaktə et';
$_['text_password']    = 'Şifrə';
$_['text_address']     = 'Ünvan kitabçası';
$_['text_wishlist']    = 'Arzu siyahısı';
$_['text_order']       = 'Sifariş tarixçəsi';
$_['text_download']    = 'Yükləmələr';
$_['text_reward']      = 'Bonus xalları';
$_['text_return']      = 'Geri qaytarma';
$_['text_transaction'] = 'Əməliyyatlar';
$_['text_newsletter']  = 'Xəbər bülleteni';
$_['text_recurring']   = 'Təkrarlanan ödəmələr';