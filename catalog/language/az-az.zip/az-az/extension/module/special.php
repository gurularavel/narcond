<?php
// Heading
$_['heading_title'] = 'Xüsusi təkliflər';

// Text
$_['text_tax']      = 'ƏDV xaric:';