<?php
// Heading
$_['heading_title']  = 'Canlı dəstək';