<?php
// Heading
$_['heading_title'] = 'Ətraflı axtarış';