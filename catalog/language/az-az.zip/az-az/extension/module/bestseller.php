<?php
// Heading
$_['heading_title'] = 'Çox satılanlar';

// Text
$_['text_tax']      = 'ƏDV xaric:';