<?php
// Heading
$_['heading_title'] = 'Son məhsullar';

// Text
$_['text_tax']      = 'ƏDV xaric:';