<?php
// Heading
$_['heading_title'] = 'Mağaza seçin';

// Text
$_['text_default']  = 'Əsas'; 
$_['text_store']    = 'Zəhmət olmasa, ziyarət etmək istədiyiniz mağazanı seçin.';