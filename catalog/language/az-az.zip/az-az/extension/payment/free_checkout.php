<?php
// Text
$_['text_title'] = 'Pulsuz sifariş';