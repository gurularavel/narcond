<?php
// Text
$_['text_title'] = 'Kredit kart / Debit kart (Skrill)';