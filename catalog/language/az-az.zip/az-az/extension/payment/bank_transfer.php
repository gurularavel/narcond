<?php
// Text
$_['text_title']				= 'Bank köçürməsi';
$_['text_instruction']			= 'Bank köçürməsinin qaydaları';
$_['text_description']			= 'Zəhmət olmasa, ümumi məbləği göstərilmiş bank hesabına köçürün';
$_['text_payment']				= 'Sizin sifarişiniz ödəniş edilməyənədək icra edilməyəcək.';