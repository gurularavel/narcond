<?php
// Text
$_['text_title']		   = 'Kredit kartı / Debit kart (Authorize.Net)';
$_['text_credit_card']     = 'Kart məlumatları';

// Entry
$_['entry_cc_owner']       = 'Kartın sahibi';
$_['entry_cc_number']      = 'Kartın nömrəsi';
$_['entry_cc_expire_date'] = 'Kartın son istifadə müddəti';
$_['entry_cc_cvv2']		   = 'Kartın təhlükəsizlik kodu (CVV2)';