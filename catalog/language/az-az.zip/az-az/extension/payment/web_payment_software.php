<?php
// Text
$_['text_title']				= 'Kredit kart / Debit kart (Web Payment Software)';
$_['text_credit_card']			= 'Kart məlumatları';

// Entry
$_['entry_cc_owner']			= 'Kartın sahibi';
$_['entry_cc_number']			= 'Kartın nömrəsi';
$_['entry_cc_expire_date']		= 'Kartın son istifadə tarixi';
$_['entry_cc_cvv2']				= 'Kartın təhlükəsizlik kodu (CVV2)';