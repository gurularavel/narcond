<?php
// Text
$_['text_title'] = 'Nəğd ödəniş';