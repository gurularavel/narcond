<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_testmode'] = 'Uyarı!!! Ödeme metodu \'Test Modundadır\'. Hesabınıza tahsilat yapılmayacaktır.';
$_['text_total']    = 'Kargolama, Ambalajlama, İndirimler & Vergiler';