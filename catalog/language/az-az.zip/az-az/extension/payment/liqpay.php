<?php
// Text
$_['text_title'] = 'Kredit kartı / Debit kart (LiqPay)';