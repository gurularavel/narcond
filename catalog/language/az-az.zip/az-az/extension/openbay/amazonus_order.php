<?php
// Text
$_['text_paid_amazon'] 			= 'Amazon US-da ödə';
$_['text_total_shipping'] 		= 'Çatdırılma';
$_['text_total_shipping_tax'] 	= 'Çatıdırılma haqqı';
$_['text_total_giftwrap'] 		= 'Hədiyyə bağlaması';
$_['text_total_giftwrap_tax'] 	= 'Hədiyyə bağlaması haqqı';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'ƏDV';
$_['text_total'] 				= 'Ümumi məbləğ';
$_['text_gift_message'] 		= 'Hədiyyə mesajları';