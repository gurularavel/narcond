<?php
// Text
$_['text_total_shipping']		= 'Çatdırılma';
$_['text_total_discount']		= 'Endirim';
$_['text_total_tax']			= 'ƏDV';
$_['text_total_sub']			= 'Məbləğ';
$_['text_total']				= 'Ümumi məbləğ';