<?php
// Text
$_['text_title']       = 'PiliExpress';
$_['text_description'] = 'PiliExpress (仅限霹雳爸爸支付, Only for Pilibaba checkout)';