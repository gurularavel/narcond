<?php
// Text
$_['text_title']       = 'Sabit qiymət';
$_['text_description'] = 'Sabit çatdırılma haqqı';