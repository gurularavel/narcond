<?php
// Text
$_['text_title']  = 'Çəkiyə görə çatdırılma';
$_['text_weight'] = 'Çəki:';