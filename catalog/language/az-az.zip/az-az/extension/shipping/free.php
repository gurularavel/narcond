<?php
// Text
$_['text_title']       = 'Pulsuz çatdırılma';
$_['text_description'] = 'Pulsuz çatdırılma';