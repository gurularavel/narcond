<?php
// Text
$_['text_title']  = 'Birləşmiş Ştatların Poçt Xidməti';
$_['text_weight'] = 'Çəki:';
$_['text_eta']    = 'Təxmini vaxt:';