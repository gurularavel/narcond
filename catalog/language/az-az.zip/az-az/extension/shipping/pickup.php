<?php
// Text
$_['text_title']       = 'Mağazadan almaq';
$_['text_description'] = 'Mağazadan almaq';