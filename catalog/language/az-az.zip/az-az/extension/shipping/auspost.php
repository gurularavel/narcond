<?php
// Text
$_['text_title'] = 'Avstraliya poçtu';