<?php
// Text
$_['text_title']       = 'Məhsul sayına görə çatdırılma';
$_['text_description'] = 'Məhsul sayına görə çatdırılma haqqı';