<?php
// Text
$_['text_klarna_fee'] = 'Klarna haqqı';