<?php
// Text
$_['text_handling'] = 'İşçilik haqqı';