<?php
// Text
$_['text_credit']   = 'Mağaza krediti';
$_['text_order_id'] = 'Sifariş №: #%s';