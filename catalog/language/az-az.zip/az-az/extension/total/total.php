<?php
// Text
$_['text_total'] = 'Ümumi məbləğ';